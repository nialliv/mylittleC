#include <stdio.h>

main () {
    int c;
    if (getchar() != EOF) {
        printf("True\n");
    }
}
