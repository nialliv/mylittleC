#include <stdio.h>

main(){
    printf("Helo\n");
    printf("Я что-то помню =)");
    int x = 1;
    int y = 2;
    printf(x,y);
    return 0;
}
