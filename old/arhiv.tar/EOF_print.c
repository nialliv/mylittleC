#include <stdio.h>

main () {
    putchar(EOF);
    printf("\n");
}
